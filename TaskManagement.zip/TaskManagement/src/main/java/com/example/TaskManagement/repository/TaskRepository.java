package com.example.TaskManagement.repository;
import com.example.TaskManagement.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
public interface TaskRepository extends JpaRepository<Task, Long>{
	List<Task> findByAssignedUserUsername(String username);
}
