package com.example.TaskManagement.controller;
import com.example.TaskManagement.entity.Task;
import com.example.TaskManagement.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/admin")

public class AdminController {
	@Autowired
    private TaskService taskService;

    @PostMapping("/tasks/{userId}")
    public Task assignTask(@PathVariable Long userId,
                           @RequestBody Task task,
                           Principal principal) {
        return taskService.assignTask(userId, task, principal.getName());
    }

    @GetMapping("/tasks")
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

}
