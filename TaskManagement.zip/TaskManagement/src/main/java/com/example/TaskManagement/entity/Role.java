package com.example.TaskManagement.entity;

public enum Role {
	ROLE_USER,
    ROLE_ADMIN,
    ROLE_DEVELOPER
}
