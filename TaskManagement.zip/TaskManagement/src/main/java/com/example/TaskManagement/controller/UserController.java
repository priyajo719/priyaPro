package com.example.TaskManagement.controller;

import com.example.TaskManagement.dto.UserResponse;
import com.example.TaskManagement.entity.Task;
import com.example.TaskManagement.entity.User;
import com.example.TaskManagement.service.TaskService;
import com.example.TaskManagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/me")
    public UserResponse currentUser(Principal principal) {
        User user = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        return new UserResponse(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getRole()
        );
    }

    @GetMapping("/tasks")
    public List<Task> myTasks(Principal principal) {
        return taskService.getUserTasks(principal.getName());
    }

    @PatchMapping("/tasks/{taskId}")
    public Task updateStatus(@PathVariable Long taskId,
                             @RequestParam com.example.TaskManagement.entity.TaskStatus status,
                             Principal principal) {
        return taskService.updateStatus(taskId, status, principal.getName());
    }
}
