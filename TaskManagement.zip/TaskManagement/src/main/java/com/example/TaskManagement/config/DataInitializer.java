package com.example.TaskManagement.config;
import com.example.TaskManagement.entity.Role;
import com.example.TaskManagement.entity.User;
import com.example.TaskManagement.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {
	 @Bean
	    CommandLineRunner initUsers(
	            UserRepository userRepository,
	            PasswordEncoder passwordEncoder) {

	        return args -> {

	            if (userRepository.findByUsername("admin").isEmpty()) {

	                User admin = new User();

	                admin.setUsername("admin");
	                admin.setPassword(
	                    passwordEncoder.encode("admin123")
	                );
	                admin.setEmail("admin@gmail.com");
	                admin.setRole(Role.ROLE_ADMIN);

	                userRepository.save(admin);
	            }

	            if (userRepository.findByUsername("user").isEmpty()) {

	                User user = new User();

	                user.setUsername("user");
	                user.setPassword(
	                    passwordEncoder.encode("user123")
	                );
	                user.setEmail("user@gmail.com");
	                user.setRole(Role.ROLE_USER);

	                userRepository.save(user);
	            }
	        };
	    }
}
