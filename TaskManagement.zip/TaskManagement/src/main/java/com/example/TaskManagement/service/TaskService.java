package com.example.TaskManagement.service;
import com.example.TaskManagement.entity.Task;
import com.example.TaskManagement.entity.TaskStatus;
import com.example.TaskManagement.entity.User;
import com.example.TaskManagement.repository.TaskRepository;
import com.example.TaskManagement.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {
	  @Autowired
	    private TaskRepository taskRepo;

	    @Autowired
	    private UserRepository userRepo;

	    // ADMIN -> assign task
	    public Task assignTask(Long userId, Task task, String adminName) {

	        User user = userRepo.findById(userId)
	                .orElseThrow(() -> new RuntimeException("User not found"));

	        task.setAssignedUser(user);
	        task.setCreatedBy(adminName);

	        return taskRepo.save(task);
	    }

	    // USER -> update task status
	    public Task updateStatus(
	            Long taskId,
	            TaskStatus status,
	            String username) {

	        Task task = taskRepo.findById(taskId)
	                .orElseThrow(() -> new RuntimeException("Task not found"));

	        if (task.getAssignedUser() == null) {
	            throw new RuntimeException("Task is not assigned to any user");
	        }

	        if (!task.getAssignedUser()
	                .getUsername()
	                .equals(username)) {

	            throw new RuntimeException("Unauthorized!");
	        }

	        task.setStatus(status);

	        return taskRepo.save(task);
	    }

	    // USER -> view own tasks
	    public List<Task> getUserTasks(String username) {
	        return taskRepo.findByAssignedUserUsername(username);
	    }

	    // ADMIN -> view all tasks
	    public List<Task> getAllTasks() {
	        return taskRepo.findAll();
	    }
}
