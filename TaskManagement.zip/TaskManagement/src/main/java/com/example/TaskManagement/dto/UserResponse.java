package com.example.TaskManagement.dto;

import com.example.TaskManagement.entity.Role;

public record UserResponse(
        Long id,
        String username,
        String email,
        Role role
) {}
