const API_URL = "";

let authHeader = "";
let currentUsername = "";
let currentRole = "";
let currentTasks = [];

// Restore login state after page refresh.
authHeader = sessionStorage.getItem("authHeader") || "";
currentUsername = sessionStorage.getItem("currentUsername") || "";
currentRole = sessionStorage.getItem("currentRole") || "";

document.addEventListener("DOMContentLoaded", () => {
    if (authHeader && currentUsername && currentRole) {
        startApplication();
    }
});


// ======================================
// LOGIN
// ======================================

document
    .getElementById("loginForm")
    .addEventListener("submit", async function (event) {

        event.preventDefault();

        const username =
            document.getElementById("username").value.trim();

        const password =
            document.getElementById("password").value;

        const errorBox =
            document.getElementById("loginError");

        errorBox.textContent = "";

        authHeader =
            "Basic " + btoa(username + ":" + password);
			sessionStorage.setItem("authHeader", authHeader);
			sessionStorage.setItem("currentUsername", username);

        try {

            /*
             * First check the admin endpoint.
             *
             * Admin users can access:
             * GET /api/admin/tasks
             */

            let response = await fetch(
                `${API_URL}/api/admin/tasks`,
                {
                    method: "GET",
                    headers: {
                        "Authorization": authHeader
                    }
                }
            );


            if (response.ok) {

                currentUsername = username;
                currentRole = "ADMIN";
				sessionStorage.setItem("currentRole", "ADMIN");
                startApplication();

                return;
            }


            /*
             * If admin endpoint returns 403,
             * check user endpoint.
             */

            response = await fetch(
                `${API_URL}/api/user/tasks`,
                {
                    method: "GET",
                    headers: {
                        "Authorization": authHeader
                    }
                }
            );


            if (response.ok) {

                currentUsername = username;
                currentRole = "USER";
				sessionStorage.setItem("currentRole", "USER");
                startApplication();

                return;
            }


            errorBox.textContent =
                "Invalid username or password.";

        } catch (error) {

            console.error(error);

            errorBox.textContent =
                "Cannot connect to backend. Make sure Spring Boot is running on port 8080.";
        }

    });


// ======================================
// START APPLICATION
// ======================================

function startApplication() {

    document
        .getElementById("loginPage")
        .classList.add("hidden");

    document
        .getElementById("app")
        .classList.remove("hidden");


    document.getElementById("sidebarUsername")
        .textContent = currentUsername;

    document.getElementById("topUsername")
        .textContent = currentUsername;

    document.getElementById("userAvatar")
        .textContent =
        currentUsername.charAt(0).toUpperCase();


    const roleText =
        currentRole === "ADMIN"
            ? "Administrator"
            : "User";

    document.getElementById("sidebarRole")
        .textContent = roleText;


    // Admin navigation
    if (currentRole === "ADMIN") {
        document.getElementById("adminNav").classList.remove("hidden");
        document.getElementById("addUserNav").classList.remove("hidden");
        loadAdminTasks();
        loadAdminUsers();
    } else {
        document.getElementById("adminNav").classList.add("hidden");
        document.getElementById("addUserNav").classList.add("hidden");
    }

    loadProfile();


    showDashboard();

    loadTasks();

}


// ======================================
// API REQUEST HELPER
// ======================================

async function apiRequest(url, options = {}) {

    options.headers = {

        ...(options.headers || {}),

        "Authorization": authHeader,

        "Content-Type": "application/json"

    };


    const response =
        await fetch(url, options);


    if (response.status === 401) {

        logout();

        throw new Error("Unauthorized");

    }


    return response;

}


// ======================================
// LOAD USER TASKS
// ======================================

async function loadTasks() {

    try {

        const response =
            await apiRequest(
                `${API_URL}/api/user/tasks`
            );


        if (!response.ok) {

            throw new Error(
                "Unable to load tasks"
            );

        }


        currentTasks =
            await response.json();


        renderTasks(currentTasks);

        updateDashboard(currentTasks);
        updateProfileStats(currentTasks);

    } catch (error) {

        console.error(error);

        document.getElementById("tasksContainer").innerHTML = `<div class="empty-state">Unable to load tasks.</div>`;

    }

}


// ======================================
// RENDER USER TASKS
// ======================================

function renderTasks(tasks) {

    const container =
        document.getElementById(
            "tasksContainer"
        );


    if (!tasks || tasks.length === 0) {

        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">✓</div>
                <p>No tasks assigned to you.</p>
            </div>
        `;

        return;
    }


    container.innerHTML =
        tasks.map(task => createTaskHTML(task))
            .join("");

}


// ======================================
// CREATE TASK HTML
// ======================================

function createTaskHTML(task) {

    const status =
        task.status || "TODO";

    const priority =
        task.priority || "MEDIUM";


    return `
        <div class="task-card">

            <div class="task-top">

                <div>

                    <div class="task-title">
                        ${escapeHTML(task.title || "Untitled Task")}
                    </div>

                    <div class="task-description">
                        ${escapeHTML(task.description || "")}
                    </div>

                </div>


                <select
                    class="status-select"
                    onchange="changeTaskStatus(${task.id}, this.value)"
                >

                    <option
                        value="TODO"
                        ${status === "TODO" ? "selected" : ""}
                    >
                        To Do
                    </option>

                    <option
                        value="IN_PROGRESS"
                        ${status === "IN_PROGRESS" ? "selected" : ""}
                    >
                        In Progress
                    </option>

                    <option
                        value="COMPLETED"
                        ${status === "COMPLETED" ? "selected" : ""}
                    >
                        Completed
                    </option>

                </select>

            </div>


            <div class="task-meta">

                <span class="badge ${statusClass(status)}">
                    ${formatStatus(status)}
                </span>

                <span class="badge ${priorityClass(priority)}">
                    ${priority}
                </span>

                <span class="badge">
                    ID: ${task.id}
                </span>

            </div>

        </div>
    `;
}


// ======================================
// UPDATE TASK STATUS
// ======================================

async function changeTaskStatus(taskId, status) {

    try {

        const response =
            await apiRequest(
                `${API_URL}/api/user/tasks/${taskId}?status=${status}`,
                {
                    method: "PATCH"
                }
            );


        if (!response.ok) {

            throw new Error(
                "Could not update task"
            );

        }


        await loadTasks();

    } catch (error) {

        console.error(error);

        alert(
            "Could not update task status."
        );

    }

}


// ======================================
// ADMIN - LOAD ALL TASKS
// ======================================

async function loadAdminUsers() {
    if (currentRole !== "ADMIN") return;

    const select = document.getElementById("assignedUserId");
    if (!select) return;

    try {
        const response = await apiRequest(`${API_URL}/api/admin/users`);
        if (!response.ok) throw new Error("Unable to load users");

        const users = await response.json();
        select.innerHTML = '<option value="">Select a user</option>' +
            users
                .filter(user => user.role !== "ROLE_ADMIN")
                .map(user =>
                    `<option value="${user.id}">${escapeHTML(user.username)} — ${escapeHTML(user.email || "No email")}</option>`
                ).join("");
    } catch (error) {
        console.error(error);
        select.innerHTML = '<option value="">Unable to load users</option>';
    }
}

async function loadAdminTasks() {

    if (currentRole !== "ADMIN") {
        return;
    }


    try {

        const response =
            await apiRequest(
                `${API_URL}/api/admin/tasks`
            );


        if (!response.ok) {

            throw new Error(
                "Unable to load admin tasks"
            );

        }


        const tasks =
            await response.json();


        renderAdminTasks(tasks);


    } catch (error) {

        console.error(error);

        document.getElementById(
            "adminTasksContainer"
        ).innerHTML = `
            <div class="empty-state">
                Unable to load tasks.
            </div>
        `;

    }

}


// ======================================
// ADMIN TASK TABLE
// ======================================

function renderAdminTasks(tasks) {

    const container =
        document.getElementById(
            "adminTasksContainer"
        );


    if (!tasks || tasks.length === 0) {

        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">▦</div>
                <p>No tasks available.</p>
            </div>
        `;

        return;
    }


    container.innerHTML =
        tasks.map(task => {

            const assignedUser =
                task.assignedUser
                    ? task.assignedUser.username
                    : "Unassigned";


            return `
                <div class="task-card">

                    <div class="task-top">

                        <div>

                            <div class="task-title">
                                ${escapeHTML(task.title || "Untitled")}
                            </div>

                            <div class="task-description">
                                ${escapeHTML(task.description || "")}
                            </div>

                        </div>

                    </div>


                    <div class="task-meta">

                        <span class="badge">
                            User: ${escapeHTML(assignedUser)}
                        </span>

                        <span class="badge ${statusClass(task.status)}">
                            ${formatStatus(task.status)}
                        </span>

                        <span class="badge ${priorityClass(task.priority)}">
                            ${task.priority || "MEDIUM"}
                        </span>

                        <span class="badge">
                            ID: ${task.id}
                        </span>

                    </div>

                </div>
            `;

        }).join("");

}


// ======================================
// ADMIN - CREATE TASK
// ======================================

document
    .getElementById("taskForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();


        const userId =
            document.getElementById(
                "assignedUserId"
            ).value;


        const title =
            document.getElementById(
                "taskTitle"
            ).value;


        const description =
            document.getElementById(
                "taskDescription"
            ).value;


        const priority =
            document.getElementById(
                "taskPriority"
            ).value;


        const status =
            document.getElementById(
                "taskStatus"
            ).value;


        const message =
            document.getElementById(
                "taskMessage"
            );


        try {

            const response =
                await apiRequest(
                    `${API_URL}/api/admin/tasks/${userId}`,
                    {
                        method: "POST",

                        body: JSON.stringify({

                            title: title,

                            description: description,

                            priority: priority,

                            status: status

                        })
                    }
                );


            if (!response.ok) {

                const errorText =
                    await response.text();

                throw new Error(
                    errorText ||
                    "Unable to create task"
                );

            }


            message.className =
                "success-message";

            message.textContent =
                "Task assigned successfully!";


            document
                .getElementById("taskForm")
                .reset();


            await loadAdminTasks();


        } catch (error) {

            console.error(error);

            message.className =
                "error-message-box";

            message.textContent =
                "Failed to assign task. Check the User ID.";

        }

    });


// ======================================
// DASHBOARD
// ======================================

function updateDashboard(tasks) {

    const total =
        tasks.length;

    const todo =
        tasks.filter(
            task => task.status === "TODO"
        ).length;

    const progress =
        tasks.filter(
            task => task.status === "IN_PROGRESS"
        ).length;

    const completed =
        tasks.filter(
            task => task.status === "COMPLETED"
        ).length;


    document.getElementById(
        "totalTasks"
    ).textContent = total;


    document.getElementById(
        "todoTasks"
    ).textContent = todo;


    document.getElementById(
        "progressTasks"
    ).textContent = progress;


    document.getElementById(
        "completedTasks"
    ).textContent = completed;


    const recent =
        tasks.slice(0, 5);


    const recentContainer =
        document.getElementById(
            "recentTasks"
        );


    if (recent.length === 0) {

        recentContainer.innerHTML = `
            <div class="empty-state">
                <p>No tasks available.</p>
            </div>
        `;

    } else {

        recentContainer.innerHTML =
            recent.map(task =>
                createTaskHTML(task)
            ).join("");

    }

}

function openAddUser() {

	 if (currentRole !== "ADMIN") {
	        alert("Only administrators can add users.");
	        return;
	    }

	    sessionStorage.setItem(
	        "authHeader",
	        authHeader
	    );

	    sessionStorage.setItem(
	        "currentUsername",
	        currentUsername
	    );

	    sessionStorage.setItem(
	        "currentRole",
	        currentRole
	    );

	    window.location.href = "add-user.html";
	}


// ======================================
// PAGE NAVIGATION
// ======================================

function hideAllSections() {

    document
        .getElementById("dashboardSection")
        .classList.add("hidden");

    document
        .getElementById("tasksSection")
        .classList.add("hidden");

    document
        .getElementById("adminSection")
        .classList.add("hidden");

    document
        .getElementById("profileSection")
        .classList.add("hidden");


    document
        .getElementById("dashboardNav")
        .classList.remove("active");

    document
        .getElementById("tasksNav")
        .classList.remove("active");

    document
        .getElementById("adminNav")
        .classList.remove("active");

    document
        .getElementById("profileNav")
        .classList.remove("active");

}


function showDashboard() {

    hideAllSections();

    document
        .getElementById("dashboardSection")
        .classList.remove("hidden");

    document
        .getElementById("dashboardNav")
        .classList.add("active");


    document.getElementById(
        "pageTitle"
    ).textContent = "Dashboard";


    document.getElementById(
        "pageSubtitle"
    ).textContent =
        "Manage your tasks efficiently";

}


function showProfile() {
    hideAllSections();

    document.getElementById("profileSection").classList.remove("hidden");
    document.getElementById("profileNav").classList.add("active");

    document.getElementById("pageTitle").textContent = "My Profile";
    document.getElementById("pageSubtitle").textContent = "View your account details and task summary";

    loadProfile();
}

async function loadProfile() {
    if (!authHeader) return;

    try {
        const response = await apiRequest(`${API_URL}/api/user/me`);

        if (!response.ok) throw new Error("Unable to load profile");

        const user = await response.json();

        const role = (user.role || "").replace("ROLE_", "");
        const roleText = role === "ADMIN" ? "Administrator" : role === "DEVELOPER" ? "Developer" : "User";

        document.getElementById("profileAvatar").textContent =
            (user.username || "U").charAt(0).toUpperCase();
        document.getElementById("profileName").textContent = user.username || "-";
        document.getElementById("profileRole").textContent = roleText;
        document.getElementById("profileId").textContent = user.id ?? "-";
        document.getElementById("profileUsername").textContent = user.username || "-";
        document.getElementById("profileEmail").textContent = user.email || "Not provided";
        document.getElementById("profileRoleDetail").textContent = roleText;

        // Use the already loaded task list for the profile summary.
        updateProfileStats(currentTasks);
    } catch (error) {
        console.error(error);
        document.getElementById("profileName").textContent = "Unable to load profile";
    }
}

function updateProfileStats(tasks) {
    const list = tasks || [];
    document.getElementById("profileTotal").textContent = list.length;
    document.getElementById("profileTodo").textContent =
        list.filter(t => t.status === "TODO").length;
    document.getElementById("profileProgress").textContent =
        list.filter(t => t.status === "IN_PROGRESS").length;
    document.getElementById("profileCompleted").textContent =
        list.filter(t => t.status === "COMPLETED").length;
}

function showTasks() {

    hideAllSections();

    document
        .getElementById("tasksSection")
        .classList.remove("hidden");

    document
        .getElementById("tasksNav")
        .classList.add("active");


    document.getElementById(
        "pageTitle"
    ).textContent = "My Tasks";


    document.getElementById(
        "pageSubtitle"
    ).textContent =
        "View and update your assigned tasks";


    loadTasks();

}


function showAdmin() {

    if (currentRole !== "ADMIN") {
        return;
    }


    hideAllSections();

    document
        .getElementById("adminSection")
        .classList.remove("hidden");

    document
        .getElementById("adminNav")
        .classList.add("active");


    document.getElementById(
        "pageTitle"
    ).textContent = "Admin Panel";


    document.getElementById(
        "pageSubtitle"
    ).textContent =
        "Assign and manage tasks";


    loadAdminTasks();

}


// ======================================
// LOGOUT
// ======================================

function logout() {

    authHeader = "";
    currentUsername = "";
    currentRole = "";
    currentTasks = [];

    sessionStorage.removeItem("authHeader");
    sessionStorage.removeItem("currentUsername");
    sessionStorage.removeItem("currentRole");

    document
        .getElementById("app")
        .classList.add("hidden");


    document
        .getElementById("loginPage")
        .classList.remove("hidden");


    document
        .getElementById("username")
        .value = "";


    document
        .getElementById("password")
        .value = "";


    document
        .getElementById("loginError")
        .textContent = "";

}


// ======================================
// HELPERS
// ======================================

function formatStatus(status) {

    switch (status) {

        case "TODO":
            return "To Do";

        case "IN_PROGRESS":
            return "In Progress";

        case "COMPLETED":
            return "Completed";

        default:
            return status || "Unknown";
    }

}


function statusClass(status) {

    switch (status) {

        case "TODO":
            return "badge-todo";

        case "IN_PROGRESS":
            return "badge-progress";

        case "COMPLETED":
            return "badge-completed";

        default:
            return "";
    }

}


function priorityClass(priority) {

    switch ((priority || "").toUpperCase()) {

        case "HIGH":
            return "badge-high";

        case "MEDIUM":
            return "badge-medium";

        case "LOW":
            return "badge-low";

        default:
            return "";
    }

}


/*
 * Prevent HTML from being injected into
 * the page when displaying API data.
 */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}