const API_URL = "http://localhost:8080";

// Get authentication information saved by index.html
const authHeader =
    sessionStorage.getItem("authHeader");

const currentRole =
    sessionStorage.getItem("currentRole");

const currentUsername =
    sessionStorage.getItem("currentUsername");


// ======================================
// CHECK ADMIN ACCESS
// ======================================

if (!authHeader || currentRole !== "ADMIN") {

    alert("You must be logged in as an administrator.");

    window.location.href = "index.html";
}


// ======================================
// DISPLAY ADMIN NAME
// ======================================

const adminNameElement =
    document.getElementById("adminName");

if (adminNameElement) {
    adminNameElement.textContent =
        currentUsername || "Admin";
}


// ======================================
// ADD USER FORM
// ======================================

document
    .getElementById("addUserForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();

        const username =
            document.getElementById("newUsername").value.trim();

        const password =
            document.getElementById("newPassword").value;

        const email =
            document.getElementById("newEmail").value.trim();

        const role =
            document.getElementById("newRole").value;

        const message =
            document.getElementById("userMessage");

        message.textContent = "";
        message.className = "";


        if (!username || !password || !email) {

            message.className = "error-message-box";
            message.textContent =
                "Please fill in all fields.";

            return;
        }


        try {

            const response = await fetch(
                `${API_URL}/api/admin/users`,
                {
                    method: "POST",

                    headers: {
                        "Authorization": authHeader,
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        username: username,
                        password: password,
                        email: email,
                        role: role
                    })
                }
            );


            if (response.status === 401) {

                message.className =
                    "error-message-box";

                message.textContent =
                    "Authentication failed. Please log in again.";

                return;
            }


            if (response.status === 403) {

                message.className =
                    "error-message-box";

                message.textContent =
                    "Access denied. Only an administrator can add users.";

                return;
            }


            if (!response.ok) {

                const errorText =
                    await response.text();

                throw new Error(
                    errorText || "Failed to create user"
                );
            }


            message.className =
                "success-message";

            message.textContent =
                "User created successfully!";


            document
                .getElementById("addUserForm")
                .reset();


        } catch (error) {

            console.error(error);

            message.className =
                "error-message-box";

            message.textContent =
                "Failed to create user. Check the backend.";
        }

    });


// ======================================
// BACK TO DASHBOARD
// ======================================

function goBack() {

    window.location.href = "index.html";
}