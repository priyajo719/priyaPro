package com.example.form.controller;
import com.example.form.entity.PersonalInfo;
import com.example.form.service.PersonalInfoService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin("*")
@RequestMapping(value ="/info")
@RestController

public class PersonalInfoController {
	private final PersonalInfoService personalInfoService;
	
	PersonalInfoController(PersonalInfoService personalInfoService){
		this.personalInfoService = personalInfoService;
	}
	
	@PostMapping
	public PersonalInfo savePersonalInfo(@RequestBody PersonalInfo personalInfo) {
	    return personalInfoService.savePersonalInfo(personalInfo);
	}
//	@PostMapping
//	public PersonalInfo addPersonalInfo(PersonalInfo personalInfo) {
//		return personalInfoService.addPersonalInfo(personalInfo);
//	}
	@GetMapping
	public List<PersonalInfo> fetchPersonalInfos(){
		return personalInfoService.fetchPersonalInfos();
	}
	@GetMapping("/{id}")
	public PersonalInfo fetchPersonalInfoById(@PathVariable("id") Long id) {
		return personalInfoService.fetchPersonalInfoById(id);
	}
}
