package com.example.form.service;
import com.example.form.entity.PersonalInfo;
import com.example.form.repository.PersonalInfoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class PersonalInfoService {
	private final PersonalInfoRepository personalInfoRepository;
	
	PersonalInfoService(PersonalInfoRepository personalInfoRepository){
		this.personalInfoRepository = personalInfoRepository;
	}
	
	public PersonalInfo savePersonalInfo(PersonalInfo personalInfo) {
	    return personalInfoRepository.save(personalInfo);
	}
	
//	public PersonalInfo addPersonalInfo(PersonalInfo personalInfo) {
//		return personalInfoRepository.save(personalInfo);
//	}
	
	public List<PersonalInfo> fetchPersonalInfos(){
		return personalInfoRepository.findAll();
	}
	
	public PersonalInfo fetchPersonalInfoById(Long id) {
		return personalInfoRepository.findById(id).orElse(null);
	}
}
