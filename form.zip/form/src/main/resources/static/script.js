console.log("JavaScript loaded");

document.getElementById("personalForm").addEventListener("submit", function(event) {

    event.preventDefault();

    console.log("Register button clicked");

    alert("Button is working!");

});
document.getElementById("personalForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const data = {
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
        firstname: document.getElementById("firstname").value,
        lastname: document.getElementById("lastname").value,
        mobile: document.getElementById("mobile").value,
        retype_password: document.getElementById("retype_password").value
    };

    console.log("Data from HTML:", data);

    fetch("http://localhost:8082/info", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log("Status:", response.status);

        if (!response.ok) {
            throw new Error("HTTP Error: " + response.status);
        }

        return response.json();
    })
    .then(result => {
        console.log("Backend response:", result);
        alert("Registration successful!");
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Registration failed: " + error.message);
    });

});