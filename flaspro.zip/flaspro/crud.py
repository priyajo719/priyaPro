from flask import *
import sqlite3

app = Flask(__name__)


# Create database table
def create_table():
    with sqlite3.connect("employeedb.db") as con:
        curd = con.cursor()

        curd.execute("""
            CREATE TABLE IF NOT EXISTS Employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                address TEXT NOT NULL
            )
        """)

        con.commit()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/add")
def add():
    return render_template("add.html")


@app.route("/savedetails", methods=["POST"])
def saveDetails():

    name = request.form["name"]
    email = request.form["email"]
    address = request.form["address"]

    with sqlite3.connect("employeedb.db") as con:

        curd = con.cursor()

        curd.execute(
            """
            INSERT INTO Employees (name, email, address)
            VALUES (?, ?, ?)
            """,
            (name, email, address)
        )

        con.commit()

    msg = "Employee successfully Added"

    return render_template("success.html", msg=msg)


@app.route("/view")
def view():

    with sqlite3.connect("employeedb.db") as con:

        con.row_factory = sqlite3.Row

        curd = con.cursor()

        curd.execute("SELECT * FROM Employees")

        rows = curd.fetchall()

    return render_template("view.html", rows=rows)


@app.route("/delete")
def delete():
    return render_template("delete.html")


@app.route("/deleterecord", methods=["POST"])
def deleterecord():

    employee_id = request.form["id"]

    with sqlite3.connect("employeedb.db") as con:

        curd = con.cursor()

        curd.execute(
            "SELECT * FROM Employees WHERE id = ?",
            (employee_id,)
        )

        row = curd.fetchone()

        if row:

            curd.execute(
                "DELETE FROM Employees WHERE id = ?",
                (employee_id,)
            )

            con.commit()

            msg = "Record successfully deleted"

        else:

            msg = "Employee ID not found"

    return render_template("delete_record.html", msg=msg)


if __name__ == "__main__":

    # Create table before starting Flask
    create_table()

    app.run(debug=True)
