import sqlite3
conn = sqlite3.connect('employee.db')
print("Database Connected")
conn.execute("""CREATE TABLE IF NOT EXISTS Employeedb(
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    name TEXT NOT NULL, 
    email TEXT UNIQUE NOT NULL, 
    address TEXT NOT NULL
    )
""")
print("Table Created")
conn.close()