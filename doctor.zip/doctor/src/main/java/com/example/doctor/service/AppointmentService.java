package com.example.doctor.service;
import com.example.doctor.entity.Appointment;
import java.util.List;

public interface AppointmentService {
	Appointment getAppointmentById(Long id);
	
	List<Appointment> getAllAppointments();
	   
	Appointment createAppointment (Appointment appointment);
	   
	Appointment deleteAppointment (Long id);
}
