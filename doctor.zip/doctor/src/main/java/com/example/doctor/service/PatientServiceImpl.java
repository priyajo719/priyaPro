package com.example.doctor.service;
import com.example.doctor.entity.Patient;

import com.example.doctor.repository.PatientRepository;
import org.springframework.stereotype.Service; 
import java.util.List; 
@Service
public class PatientServiceImpl implements PatientService{
	private final PatientRepository patientRepository;

    public PatientServiceImpl(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    @Override
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @Override
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public Patient deletePatient(Long id) {
        Patient patient = patientRepository.findById(id).orElse(null);

        if (patient != null) {
            patientRepository.deleteById(id);
        }

        return patient;
    }
}
