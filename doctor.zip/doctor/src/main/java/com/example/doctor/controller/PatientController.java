package com.example.doctor.controller;
import com.example.doctor.entity.Patient;

import com.example.doctor.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/patients")

public class PatientController {
	 @Autowired
	    private PatientService patientService;

	    @GetMapping
	    public List<Patient> getAllPatients() {
	        return patientService.getAllPatients();
	    }

	    @GetMapping("/{id}")
	    public Patient getPatientById(@PathVariable Long id) {
	        return patientService.getPatientById(id);
	    }

	    @PostMapping
	    public Patient createPatient(@RequestBody Patient patient) {
	        return patientService.createPatient(patient);
	    }

	    @DeleteMapping("/{id}")
	    public void deletePatient(@PathVariable Long id) {
	        patientService.deletePatient(id);
	    }

}
