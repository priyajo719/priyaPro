package com.example.doctor.service;
import com.example.doctor.entity.Patient;
import java.util.List;
public interface PatientService {
	Patient getPatientById(Long id);
	
	List<Patient> getAllPatients();
	   
	Patient createPatient (Patient patient);
	   
	Patient deletePatient (Long id);

}
