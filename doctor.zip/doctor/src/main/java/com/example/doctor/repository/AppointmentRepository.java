package com.example.doctor.repository;
import com.example.doctor.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AppointmentRepository extends JpaRepository<Appointment, Long>{

}
