package com.example.doctor.repository;
import com.example.doctor.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PatientRepository extends JpaRepository<Patient, Long>  {
	
}
