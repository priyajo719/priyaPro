package com.example.doctor.service;
import com.example.doctor.entity.Appointment; 
import com.example.doctor.repository.AppointmentRepository;
import org.springframework.stereotype.Service; 
import java.util.List; 
@Service
public class AppointmentServiceImpl implements AppointmentService {
	 private final AppointmentRepository appointmentRepository;

	    public AppointmentServiceImpl(AppointmentRepository appointmentRepository) {
	        this.appointmentRepository = appointmentRepository;
	    }

	    @Override
	    public Appointment getAppointmentById(Long id) {
	        return appointmentRepository.findById(id).orElse(null);
	    }

	    @Override
	    public List<Appointment> getAllAppointments() {
	        return appointmentRepository.findAll();
	    }

	    @Override
	    public Appointment createAppointment(Appointment appointment) {
	        return appointmentRepository.save(appointment);
	    }

	    @Override
	    public Appointment deleteAppointment(Long id) {
	        Appointment appointment = appointmentRepository.findById(id).orElse(null);

	        if (appointment != null) {
	            appointmentRepository.deleteById(id);
	        }

	        return appointment;
	    }
}
