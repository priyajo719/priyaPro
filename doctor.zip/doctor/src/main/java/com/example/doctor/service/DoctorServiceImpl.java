package com.example.doctor.service;
import com.example.doctor.entity.Doctor;

import com.example.doctor.repository.DoctorRepository;
import org.springframework.stereotype.Service; 
import java.util.List; 
@Service
public class DoctorServiceImpl implements DoctorService {
	private final DoctorRepository doctorRepository;

    public DoctorServiceImpl(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    @Override
    public Doctor getDoctorById(Long id) {
        return doctorRepository.findById(id).orElse(null);
    }

    @Override
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    @Override
    public Doctor createDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    @Override
    public Doctor deleteDoctor(Long id) {
        Doctor doctor = doctorRepository.findById(id).orElse(null);

        if (doctor != null) {
            doctorRepository.deleteById(id);
        }

        return doctor;
    }
}
