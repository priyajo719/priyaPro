package com.example.doctor.service;
import com.example.doctor.entity.Doctor;

import java.util.List;

public interface DoctorService {	
	Doctor getDoctorById(Long id);
	
	List<Doctor> getAllDoctors();
	   
	Doctor createDoctor (Doctor doctor);
	   
	Doctor deleteDoctor (Long id);

}

