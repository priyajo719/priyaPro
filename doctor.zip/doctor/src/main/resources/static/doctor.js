/**
 * 
 */const API = "";

// ==========================================
// LOAD ALL DATA
// ==========================================

async function loadData() {

await loadDoctors();
await loadPatients();
await loadAppointments();

}

// ==========================================
// DOCTORS
// ==========================================

async function loadDoctors() {

try {

    const response = await fetch(`${API}/doctors`);

    if (!response.ok) {
        throw new Error("Failed to load doctors");
    }

    const doctors = await response.json();

    const doctorList =
        document.getElementById("doctorList");

    const doctorSelect =
        document.getElementById("appointmentDoctor");

    doctorList.innerHTML = "";

    doctorSelect.innerHTML =
        `<option value="">Select Doctor</option>`;


    document.getElementById("doctorCount")
        .textContent = doctors.length;


    doctors.forEach(doctor => {

        // Doctor card

        const card =
            document.createElement("div");

        card.className = "card";

        card.innerHTML = `
            <h3>Dr. ${doctor.name}</h3>

            <p>
                <strong>Specialty:</strong>
                ${doctor.specialty}
            </p>

            <p>
                <strong>ID:</strong>
                ${doctor.id}
            </p>

            <button
                class="delete-btn"
                onclick="deleteDoctor(${doctor.id})">
                Delete
            </button>
        `;

        doctorList.appendChild(card);


        // Appointment dropdown

        const option =
            document.createElement("option");

        option.value = doctor.id;

        option.textContent =
            `Dr. ${doctor.name} - ${doctor.specialty}`;

        doctorSelect.appendChild(option);

    });

} catch (error) {

    console.error(error);

    document.getElementById("doctorList")
        .innerHTML =
        "<p>Unable to load doctors.</p>";
}

}

// Add doctor

document
.getElementById("doctorForm")
.addEventListener("submit", async function(event) {

    event.preventDefault();


    const doctor = {

        name:
            document.getElementById("doctorName").value,

        specialty:
            document.getElementById("doctorSpecialty").value

    };


    try {

        const response = await fetch(
            `${API}/doctors`,
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify(doctor)
            }
        );


        if (!response.ok) {
            throw new Error("Failed");
        }


        alert("Doctor added successfully!");

        this.reset();

        loadDoctors();

    } catch (error) {

        console.error(error);

        alert("Unable to add doctor.");
    }

});

// Delete doctor

async function deleteDoctor(id) {

if (!confirm("Delete this doctor?")) {
    return;
}


try {

    const response =
        await fetch(
            `${API}/doctors/${id}`,
            {
                method: "DELETE"
            }
        );


    if (!response.ok) {
        throw new Error("Delete failed");
    }


    alert("Doctor deleted.");

    loadDoctors();

} catch (error) {

    console.error(error);

    alert(
        "Unable to delete doctor. " +
        "The doctor may have appointments."
    );
}

}

// ==========================================
// PATIENTS
// ==========================================

async function loadPatients() {

try {

    const response =
        await fetch(`${API}/patients`);


    if (!response.ok) {
        throw new Error(
            "Failed to load patients"
        );
    }


    const patients =
        await response.json();


    const patientList =
        document.getElementById("patientList");


    const patientSelect =
        document.getElementById(
            "appointmentPatient"
        );


    patientList.innerHTML = "";

    patientSelect.innerHTML =
        `<option value="">Select Patient</option>`;


    document.getElementById("patientCount")
        .textContent = patients.length;


    patients.forEach(patient => {

        // Patient card

        const card =
            document.createElement("div");

        card.className = "card";


        card.innerHTML = `
            <h3>${patient.name}</h3>

            <p>
                <strong>ID:</strong>
                ${patient.id}
            </p>

            <button
                class="delete-btn"
                onclick="deletePatient(${patient.id})">
                Delete
            </button>
        `;


        patientList.appendChild(card);


        // Appointment dropdown

        const option =
            document.createElement("option");

        option.value = patient.id;

        option.textContent =
            `${patient.name} (ID: ${patient.id})`;

        patientSelect.appendChild(option);

    });

} catch (error) {

    console.error(error);

    document.getElementById("patientList")
        .innerHTML =
        "<p>Unable to load patients.</p>";
}

}

// Add patient

document
.getElementById("patientForm")
.addEventListener("submit", async function(event) {

    event.preventDefault();


    const patient = {

        name:
            document.getElementById(
                "patientName"
            ).value

    };


    try {

        const response =
            await fetch(
                `${API}/patients`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(patient)
                }
            );


        if (!response.ok) {
            throw new Error("Failed");
        }


        alert("Patient added successfully!");

        this.reset();

        loadPatients();

    } catch (error) {

        console.error(error);

        alert("Unable to add patient.");
    }

});

// Delete patient

async function deletePatient(id) {

if (!confirm("Delete this patient?")) {
    return;
}


try {

    const response =
        await fetch(
            `${API}/patients/${id}`,
            {
                method: "DELETE"
            }
        );


    if (!response.ok) {
        throw new Error("Delete failed");
    }


    alert("Patient deleted.");

    loadPatients();

} catch (error) {

    console.error(error);

    alert(
        "Unable to delete patient."
    );
}

}

// ==========================================
// APPOINTMENTS
// ==========================================

async function loadAppointments() {

try {

    const response =
        await fetch(
            `${API}/appointments`
        );


    if (!response.ok) {
        throw new Error(
            "Failed to load appointments"
        );
    }


    const appointments =
        await response.json();


    const appointmentList =
        document.getElementById(
            "appointmentList"
        );


    document.getElementById(
        "appointmentCount"
    ).textContent =
        appointments.length;


    appointmentList.innerHTML = `

        <div class="appointment-row appointment-header">

            <div>Doctor</div>

            <div>Patient</div>

            <div>Appointment Time</div>

            <div>Action</div>

        </div>
    `;


    appointments.forEach(appointment => {

        const doctor =
            appointment.doctor;

        const patient =
            appointment.patient;


        const row =
            document.createElement("div");

        row.className =
            "appointment-row";


        row.innerHTML = `

            <div>
                Dr. ${doctor?.name || "Unknown"}
            </div>

            <div>
                ${patient?.name || "Unknown"}
            </div>

            <div>
                ${formatDate(
                    appointment.appointmentTime
                )}
            </div>

            <div>

                <button
                    class="delete-btn"
                    onclick="deleteAppointment(
                        ${appointment.id}
                    )">

                    Delete

                </button>

            </div>
        `;


        appointmentList.appendChild(row);

    });

} catch (error) {

    console.error(error);

    document.getElementById(
        "appointmentList"
    ).innerHTML =
        "<p>Unable to load appointments.</p>";
}

}

// Create appointment

document
.getElementById("appointmentForm")
.addEventListener("submit", async function(event) {

    event.preventDefault();


    const doctorId =
        document.getElementById(
            "appointmentDoctor"
        ).value;


    const patientId =
        document.getElementById(
            "appointmentPatient"
        ).value;


    const appointmentTime =
        document.getElementById(
            "appointmentTime"
        ).value;


    const appointment = {

        doctor: {
            id: Number(doctorId)
        },

        patient: {
            id: Number(patientId)
        },

        appointmentTime:
            appointmentTime + ":00"

    };


    try {

        const response =
            await fetch(
                `${API}/appointments`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            appointment
                        )
                }
            );


        if (!response.ok) {
            throw new Error(
                "Appointment failed"
            );
        }


        alert(
            "Appointment booked successfully!"
        );


        this.reset();

        loadAppointments();

    } catch (error) {

        console.error(error);

        alert(
            "Unable to book appointment."
        );
    }

});

// Delete appointment

async function deleteAppointment(id) {

if (!confirm(
    "Delete this appointment?"
)) {
    return;
}


try {

    const response =
        await fetch(
            `${API}/appointments/${id}`,
            {
                method: "DELETE"
            }
        );


    if (!response.ok) {
        throw new Error(
            "Delete failed"
        );
    }


    alert(
        "Appointment deleted."
    );


    loadAppointments();

} catch (error) {

    console.error(error);

    alert(
        "Unable to delete appointment."
    );
}

}

// ==========================================
// FORMAT DATE
// ==========================================

function formatDate(dateTime) {

if (!dateTime) {
    return "Not specified";
}


const date =
    new Date(dateTime);


return date.toLocaleString();

}

// ==========================================
// START APPLICATION
// ==========================================

loadData();