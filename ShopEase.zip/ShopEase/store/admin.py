from django.contrib import admin
from .models.products import Products
from .models.category import Category


@admin.register(Products)
class ProductsAdmin(admin.ModelAdmin):
    list_display = (
        'name',
        'price',
        'category',
    )

    list_filter = (
        'category',
    )

    search_fields = (
        'name',
        'description',
    )


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = (
        'name',
    )

    search_fields = (
        'name',
    )
# Register your models here.
