from django.contrib import admin
from .models.products import Products
from .models.category import Category
from .models.orders import Order


@admin.register(Products)
class ProductsAdmin(admin.ModelAdmin):
    list_display = (
        'name',
        'price',
        'category',
    )

    list_filter = (
        'category',
    )

    search_fields = (
        'name',
        'description',
    )


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = (
        'name',
    )

    search_fields = (
        'name',
    )
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'customer',
        'product',
        'quantity',
        'price',
        'status',
        'date',
    )

    list_filter = (
        'status',
        'date',
    )

    search_fields = (
        'customer__name',
        'product__name',
    )
# Register your models here.
