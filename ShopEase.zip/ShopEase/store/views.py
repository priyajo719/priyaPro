from django.shortcuts import render
from .models.products import Products


def product_list(request):
    products = Products.get_all_products()
    return render(request, "index.html", {"products": products, "categories": []})
