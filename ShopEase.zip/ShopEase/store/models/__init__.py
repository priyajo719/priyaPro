class Product:
    pass