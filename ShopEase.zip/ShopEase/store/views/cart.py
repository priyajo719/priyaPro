from django.shortcuts import render
from django.views import View

from store.models.products import Products


class Cart(View):
    def get(self, request):
        cart = request.session.get("cart", {})
        products = list(Products.get_products_by_id(list(cart.keys())))

        total = 0
        for product in products:
            quantity = int(cart.get(str(product.id), cart.get(product.id, 1)))
            product.cart_quantity = quantity
            product.line_total = product.price * quantity
            total += product.line_total

        return render(
            request,
            "cart.html",
            {
                "products": products,
                "cart": cart,
                "total": total,
            },
        )
