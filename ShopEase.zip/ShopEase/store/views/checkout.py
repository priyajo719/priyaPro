from django.contrib import messages
from django.shortcuts import redirect, render
from django.views import View

from store.models.customer import Customer
from store.models.orders import Order
from store.models.products import Products


class CheckOut(View):
    def get(self, request):
        cart = request.session.get("cart", {})
        products = list(Products.get_products_by_id(list(cart.keys())))

        total = 0
        for product in products:
            quantity = int(cart.get(str(product.id), cart.get(product.id, 1)))
            product.cart_quantity = quantity
            product.line_total = product.price * quantity
            total += product.line_total

        return render(
            request,
            "checkout.html",
            {
                "products": products,
                "total": total,
            },
        )

    def post(self, request):
        address = request.POST.get("address", "").strip()
        phone = request.POST.get("phone", "").strip()
        customer_id = request.session.get("customer")
        cart = request.session.get("cart", {})

        if not customer_id or not cart:
            return redirect("cart")

        products = Products.get_products_by_id(list(cart.keys()))

        for product in products:
            quantity = int(cart.get(str(product.id), cart.get(product.id, 1)))
            Order.objects.create(
                customer=Customer(id=customer_id),
                product=product,
                price=product.price,
                address=address,
                phone=phone,
                quantity=quantity,
            )

        request.session["cart"] = {}
        messages.success(
            request,
            "Order placed successfully! For support, contact ShopEase at 7708583748."
        )
        return redirect("orders")
