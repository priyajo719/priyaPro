from django.shortcuts import render
from django.views import View

from store.models.orders import Order


class OrderView(View):
    def get(self, request):
        customer = request.session.get("customer")
        orders = list(Order.get_orders_by_customer(customer))

        for order in orders:
            order.total_price = order.price * order.quantity

        return render(request, "orders.html", {"orders": orders})
