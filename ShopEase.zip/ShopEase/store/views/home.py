from django.shortcuts import (render, redirect)
from django.http import HttpResponseRedirect
from store.models.products import Products
from store.models.category import Category
from django.views import View


# Create your views here.
class Index(View):

	def post(self, request):
		product = request.POST.get('product')
		remove = request.POST.get('remove')
		cart = request.session.get('cart')
		if cart:
			quantity = cart.get(product)
			if quantity:
				if remove:
					if quantity <= 1:
						cart.pop(product)
					else:
						cart[product] = quantity-1
				else:
					cart[product] = quantity+1

			else:
				cart[product] = 1
		else:
			cart = {}
			cart[product] = 1

		request.session['cart'] = cart
		print('cart', request.session['cart'])
		return redirect('homepage')

	def get(self, request):
		# print()
		return HttpResponseRedirect(f'/store{request.get_full_path()[1:]}')


def store(request):
    cart = request.session.get('cart')
    if not cart:
        request.session['cart'] = {}

    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')

    selected_category = None

    if categoryID:
        products = Products.get_all_products_by_categoryid(categoryID)

        try:
            selected_category = Category.objects.get(id=categoryID)
        except Category.DoesNotExist:
            selected_category = None
    else:
        products = Products.get_all_products()

    data = {}
    data['products'] = products
    data['categories'] = categories
    data['selected_category'] = selected_category

    print('you are : ', request.session.get('email'))

    return render(request, 'index.html', data)