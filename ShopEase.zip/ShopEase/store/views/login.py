from django.contrib.auth.hashers import check_password
from django.shortcuts import redirect, render
from django.views import View

from store.models.customer import Customer


class Login(View):
    def get(self, request):
        return_url = request.GET.get("return_url", "")
        return render(request, "login.html", {"return_url": return_url})

    def post(self, request):
        email = request.POST.get("email", "").strip().lower()
        password = request.POST.get("password", "")
        return_url = request.POST.get("return_url") or request.GET.get("return_url", "")

        customer = Customer.get_customer_by_email(email)

        if customer and check_password(password, customer.password):
            request.session["customer"] = customer.id
            request.session.set_expiry(
                1209600 if request.POST.get("remember") else 0
            )

            if return_url and return_url.startswith("/") and not return_url.startswith("//"):
                return redirect(return_url)

            return redirect("homepage")

        return render(
            request,
            "login.html",
            {
                "error": "Invalid email or password.",
                "email": email,
                "return_url": return_url,
            },
        )


def logout(request):
    request.session.flush()
    return redirect("login")
