ShopEase / MyStore - fixed Django project

Run from the folder containing manage.py:

1. Activate your virtual environment.
2. python manage.py check
3. python manage.py runserver

Open:
http://127.0.0.1:8000/

This copy fixes the missing shared/auth/cart/checkout/order CSS, broken URL names,
cart quantity/total handling, checkout GET handling, product add-to-cart button,
login redirect handling, and media/static configuration for development.
